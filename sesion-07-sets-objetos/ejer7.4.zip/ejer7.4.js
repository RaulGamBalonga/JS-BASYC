const edad = prompt("¿Cuántos años tienes?");
