//ejercicio 1.
const familia = ["Dante", "Antonia", "Natalia", "Pavlo"];
console.log(familia);

const setFamilia = new Set(familia);
console.log(setFamilia);

setFamilia.add("Dante");

setFamilia.add("JavaScript");
