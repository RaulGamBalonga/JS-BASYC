const altura_cm = 190
const altura_m = 1.90
const peso_kg = 73.5

const altura_redon = Math.ceil(altura_m)
const peso_redon = Math.floor(peso_kg)

const sonIguales = Number.MAX_VALUE + 1 === Number.MAX_VALUE